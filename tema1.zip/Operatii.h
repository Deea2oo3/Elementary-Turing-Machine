/*OLTEANU Andreea-Denisa - 311 CD*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Stiva.h"
#include "Coada.h"

// Definirea functiilor pentru operatiile problemei

// Afisarea benzii

void SHOW(List *banda, FILE *fisier_out) {
	// Pornim de la primul nod accesibil benzii
	// si scriem in fisier fiecare element
	ListNode *p = banda->santinela->next;
	while (p != NULL) {
		if (p == banda->poz) {
			// Cand ajungem la elementul curent il vom scrie
			// in fisier intre | |
			fprintf(fisier_out, "|%c|", p->elem[0]);
		} else {
			fprintf(fisier_out, "%c", p->elem[0]);
		}
	p = p->next;
	}
	fprintf(fisier_out, "\n");
}

// Mutarea catre stanga a pozitiei degetului, daca este posibila

void MOVE_LEFT(List *banda) {
	// Verificam daca putem sa ne mutam mai la stanga
	if (banda->poz->prev == NULL) {
		return;
	} else {
		banda->poz = banda->poz->prev;
	}
}

// Mutarea catre dreapta a pozitiei degetului

void MOVE_RIGHT(List *banda) {
	// Verificam daca ne aflam pe ultimul nod, caz in care creez un nou nod
	if (banda->poz->next == NULL) {
		char c = '#';
		ListNode *nod = createNode(c);
		banda->poz->next = nod;
		nod->prev = banda->poz;
		banda->poz = nod;
	} else {
		banda->poz = banda->poz->next;
	}
}

// Mutarea catre stanga a pozitiei degetului pana la intalnirea
// unui caracter dat, daca este posibil

void MOVE_LEFT_CHAR(List *banda, char elem, FILE *fisier_out) {
	ListNode *p = banda->poz;
	// Verificam daca gasim caracterul dat in banda
	// mutandu-ne cate o pozitie la stanga
	while (p->elem[0] != elem){
		// In cazul in care nu ne mai putem muta mai la stanga
		// in fisier se va scrie "ERROR"
		if (p->prev == NULL) {
			fprintf(fisier_out, "ERROR\n");
			return;
		} else {
			p = p->prev;
		}
	}
	banda->poz = p;
}

// Mutarea catre dreapta a pozitiei degetului pana la
// intalnirea unui caracter dat

void MOVE_RIGHT_CHAR(List *banda, char elem) {
	// Verificam daca gasim caracterul dat in banda
	// mutandu-ne cate o pozitie la dreapta
	while (banda->poz->elem[0] != elem){
		// In cazul in care ajungem la ultimul nod al
		// benzii, creez un nou nod
		if (banda->poz->next == NULL) {
			char c = '#';
			ListNode *nod = createNode(c);
			banda->poz->next = nod;
			nod->prev = banda->poz;
			banda->poz = nod;
			return;
		} else {
			banda->poz = banda->poz->next;
		}
	}
}

// Inlocuirea elementului de la pozitia la care ne aflam
// cu un caracter dat

void WRITE(List *banda, char elem) {
	banda->poz->elem[0] = elem;
}

// Inserarea la stanga fata de pozitia la care ne aflam a
// unui caracter dat, daca este posibil

void INSERT_LEFT(List *banda, char elem, FILE *fisier_out) {
	// Verificam daca putem insera la stanga, iar in caz
	// negativ in fisier se va scrie "ERROR", altfel
	// creez un nou nod care contine caracterul dat
	if (banda->poz->prev == NULL) {
		fprintf(fisier_out, "ERROR\n");
	} else {
		ListNode *nod = createNode(elem);
		nod->prev = banda->poz->prev;
		nod->next = banda->poz;
		banda->poz->prev->next = nod;
		banda->poz->prev = nod;
		banda->poz = nod;
		if (banda->poz == banda->santinela->next) {
			banda->santinela->next = nod;
		}
	}
}

// Inserarea la dreapta fata de pozitia la care ne aflam a
// unui caracter dat

void INSERT_RIGHT(List *banda, char elem) {
	// Verificam daca ne aflam pe ultimul nod al benzii,
	// dupa care creez nodul cerut
	if (banda->poz->next == NULL) {
		ListNode *nod = createNode(elem);
		banda->poz->next = nod;
		nod->prev = banda->poz;
		banda->poz = nod;
	} else {
		ListNode *nod = createNode(elem);
		nod->next = banda->poz->next;
		banda->poz->next = nod;
		nod->prev = banda->poz;
		banda->poz = nod;
	}
}

// Afisarea elementului curent

void SHOW_CURRENT(List *banda, FILE *fisier_out) {
	fprintf(fisier_out, "%c\n", banda->poz->elem[0]);
}

// Functia pentru operatia de UNDO

void UNDO(List *banda, Stack *undo, Stack *redo) {
	// Adaugam pozitia pe care ne aflam in stiva redo, dupa care
	// scoatem pozitia din stiva undo si mutam degetul pe aceasta pozitie
	push(redo, banda->poz);
	ListNode *p = pop(undo);
	banda->poz = p;
}

// Functia pentru operatia de REDO

void REDO(List *banda, Stack *undo, Stack *redo) {
	// Adaugam pozitia pe care ne aflam in stiva undo, dupa care
	// scoatem pozitia din stiva redo si mutam degetul pe aceasta pozitie
	push(undo, banda->poz);
	ListNode *p = pop(redo);
	banda->poz = p;
}

// Functia pentru executarea operatiilor de tip UPDATE:
// MOVE_LEFT, MOVE_RIGHT, MOVE_LEFT_CHAR, MOVE_LEFT_RIGHT,
// WRITE, INSERT_LEFT, INSERT_RIGHT

void EXECUTE(List *banda, Queue *operatii, Stack *undo, Stack *redo,
			FILE *fisier_out) {
	ListNode *q = banda->poz;
	char sir[string_len];
	strcpy(sir, operatii->front->elem);
	// Verificam care operatie din cele de tipul UPDATE
	// trebuie facuta si o executam
	if (strlen(sir) == strlen("MOVE_LEFT\n")) {
		MOVE_LEFT(banda);
		if (banda->poz != q){
			push(undo, q);
		}
	} else if (strlen(sir) == strlen("MOVE_RIGHT\n")) {
			MOVE_RIGHT(banda);
			if (banda->poz != q) {
				push(undo, q);
			}
	} else if (strstr(sir, "MOVE_LEFT_CHAR")) {
			MOVE_LEFT_CHAR(banda, operatii->front->elem[strlen(sir)-2], fisier_out);
	} else if (strstr(sir, "MOVE_RIGHT_CHAR")) {
			MOVE_RIGHT_CHAR(banda, operatii->front->elem[strlen(sir)-2]);
	} else if (strstr(sir, "WRITE")) {
			WRITE(banda, operatii->front->elem[strlen(sir)-2]);
	} else if (strstr(sir, "INSERT_LEFT")) {
			INSERT_LEFT(banda, operatii->front->elem[strlen(sir)-2], fisier_out);
	} else if (strstr(sir, "INSERT_RIGHT")) {
			INSERT_RIGHT(banda, operatii->front->elem[strlen(sir)-2]);
	}
	// Scoatem operatia din coada cu operatii
	dequeue(operatii);
}
