/*OLTEANU Andreea-Denisa - 311 CD*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Lista.h"

// Definirea structurilor si functiilor pentru stiva

typedef struct StackNode {
	struct ListNode *poz;   // Data pe care o retinem in nod
	struct StackNode *next; // Pointerul catre urmatorul nod al stivei
} StackNode;

typedef struct Stack {
	StackNode* head;  // Varful stivei
	long size;        // Numarul de elemente din stiva
} Stack;

// Creez nodul stivei

StackNode *createStackNode(ListNode *poz) {
	StackNode *nod = malloc (sizeof(struct StackNode));
	nod->poz = poz;
	nod->next = NULL;
	return nod;
}

// Creez stiva

Stack *createStack(void) {
	Stack *stack = malloc(sizeof(struct Stack));
	stack->head = NULL;
}

// Adaugarea unui element in varful stivei

void push(Stack *stack, ListNode *poz) {
	if (stack->head == NULL) {
		StackNode *nod = createStackNode(poz);
		stack->head = nod;
		stack->size = 1;
		return;
	}
    stack->size++;
	StackNode *nod = createStackNode(poz);
	nod->next = stack->head;
	stack->head = nod;
	return;
}

// Returnarea si scoaterea primului element din stiva

ListNode *pop(Stack *stack) {
	ListNode *poz = stack->head->poz;
	stack->size--;
	StackNode *p =stack->head;
	stack->head = stack->head->next;
	free(p);
	return poz;
}

// Eliberarea memoriei stivei

void destroyStack(Stack *stack) {
	StackNode *p =stack->head;
	while (stack->head != NULL) {
		stack->head = stack->head->next;
		free(p);
		p = stack->head;
	}
	free(stack);
}
