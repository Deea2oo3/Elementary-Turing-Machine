La rularea pe calculatorul propriu obtin 100/100 pe teste si 20/20 pe valgrind
Programul contine un fisier sursa .c si patru headere .h
In tema1.c in main se creeaza banda, coada cu operatiile si stivele de undo si
redo. Dupa aceea se deschid fisierele, urmand ca din fisierul fisier_in sa
citim operatiile ce trebuie facute. Acesta operatii sunt puse pe rand intr-un
sir pentru a putea verifica ce operatie trebuie facuta, dupa care este apelata
functia aferenta operatiei. Toate operatiile de tipul UPDATE nu sunt efectuate
atunci cand sunt gasite, ci sunt puse in coada de comenzi pana la gasirea ope-
ratiei de EXECUTE.
Operatii.h - contine functiile pentru implementarea operatiilor din cerinta
        problemei
In functia SHOW parcurgem intreaga banda si scriem in fisier data stocata in
fiecare nod, punand intre | | elementul de la pozitia la care se afla degetul
In functia MAKE_LEFT mutam degetul cu o pozitie mai la stanga daca este posibil
In functia MAKE_RIGHT mutam degetul cu o pozitie mai la dreapta, iar in cazul
in care ne aflam pe ultima pozitie din banda inseram un nou nod la finalul
benzii
In functia MAKE_LEFT_CHAR parcurgem banda de la pozitia curenta spre stanga
pana cand gasim elementul dat, iar in cazul in care ajungem la inceputul benzii
si nu am gasit elementul vom scrie in fisier "ERROR"
In functia MAKE_RIGHT_CHAR parcurgem banda de la pozitia curenta spre dreapta
pana cand gasim elementul dat, iar in cazul in care ajungem la finalul benzii
si nu am gasit elementul vom adauga un nou nod la finalul benzii
In functia WRITE scriem un element dat in data stocata la nodul spre care
pointeaza pozitia degetului
In functia INSERT_LEFT vom insera pe pozitia din stanga degetului un nou nod,
iar in caz contrar se scrie in fisier "ERROR"
In functia INSERT_RIGHT vom insera pe pozitia din dreapta degetului un nou nod
In functia SHOW_CURRENT scriem in fisier data stocata in nodul la care pointea-
za pozitia degetului
In functia UNDO mutam pozitia degetului la pozitia anterioara
In functia REDO refacem ultima operatie prin care s-a mutat pozitia degetului
In functia EXECUTE vom lua primul element din coada cu operatii si vom afla
ce operatie de tip UPDATE trebuie facuta, urmand ca aceasta sa fie si executata
Coada.h - contine structurile si operatiile necesare pentru coada de comenzi
In functia createQueueNode alocam dinamic memorie pentru un nod al cozii
In functia createQueue alocam dinamic memorie pentru o coada
In functia enqueue adaugam in coada un nou element
In functia dequeue scoatem din coada primul element din coada
Lista.h - contine structurile si operatiile necesare pentru banda
In functia createNode alocam dinamic memorie pentru un nod al listei
In functia createBanda alocam dinamic memorie pentru banda ceruta in enuntul
problemei
In functia destroyList eliberam memoria alocata dinamic pentru banda
Stiva.h - contine structurile necesare pentru stivele de undo si redo necesare
        functiilor UNDO si REDO
In functia createStackNode alocam dinamic memorie pentru un nod al stivei
In functia createStack alocam dinamic memorie pentru o stiva
In functia push adaugam un element in varful stivei
In functia pop scoatem elementul din varful stivei
In functia destroyStack eliberam memoria alocata dinamic pentru stiva