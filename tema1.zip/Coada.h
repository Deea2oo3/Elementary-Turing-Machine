/*OLTEANU Andreea-Denisa - 311 CD*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define string_len 20

// Definirea cozii si a functiilor pentru crearea cozii,
// inserarea in coada a unui element si scoaterea din
// coada a unui element

typedef struct QueueNode {
	char *elem;             // Data stocata in nod
	struct QueueNode *next; // Pointerul catre urmatorul nod al cozii
}QueueNode;

typedef struct Queue {
	QueueNode *front; // Primul nod al cozii
	QueueNode *rear;  // Ultimul nod al cozii
	long size;        // Lungimea cozii
}Queue;

// Creez nodul cozii

QueueNode *createQueueNode(char *elem) {
	QueueNode *nod = malloc (sizeof(struct QueueNode));
	nod->elem = malloc(string_len*sizeof(char));
	strcpy(nod->elem, elem);
	nod->next = NULL;
	return nod;
}

// Creez o coada

Queue *createQueue(void) {
	Queue *queue = malloc(sizeof(struct Queue));
	queue->front = queue->rear = NULL;
	return queue;
}

// Adaugarea unui element in coada

void enqueue(Queue *q, char *elem) {
	if (q->front == NULL) {
		QueueNode *nod = createQueueNode(elem);
		q->front = q->rear = nod;
		q->size = 1;
		return;
	}
    q->size++;
	QueueNode *nod = createQueueNode(elem);
	nod->next = NULL;
	q->rear->next = nod;
	q->rear = nod;
	return;
}

// Scoaterea unui element din coada

void dequeue(Queue *q) {
	if (q->front == NULL) {
		return;
	}
	QueueNode *p = q->front;
	q->size--;
	q->front = q->front->next;
	if (q->size == 0) {
		q->front = q->rear = NULL;
	}
	free(p->elem);
	free(p);
}


