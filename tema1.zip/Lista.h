/*OLTEANU Andreea-Denisa - 311 CD*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define string_len 20

// Definirea structurilor si a functilor pentru lista

typedef struct ListNode {
	char *elem;            // Data stocata in nod
	struct ListNode* next; // Legatura catre nodul urmator
	struct ListNode* prev; // Legatura catre nodul anterior
} ListNode;

typedef struct List {
	ListNode* poz; // Pozitia degetului
	ListNode* santinela;
}List;

// Creez nodul listei

ListNode *createNode(char elem) {
	ListNode *nod = malloc(sizeof(struct ListNode));
	nod->elem = malloc(string_len*sizeof(char));
	nod->elem[0] = elem;
	nod->next = nod->prev = NULL;
	return nod;
}

// Creez banda din cerinta

List* createBanda(void) {
	List *banda = malloc(sizeof(struct List));
	ListNode *santinela = createNode('\n');
	banda->santinela = santinela;
	banda->poz = NULL;
	ListNode *nod = createNode('#');
	banda->poz = nod;
	banda->santinela->next = banda->poz;
	return banda;
}

// Eliberarea memoriei listei

List* destroyList(List* lista) {
	if (lista == NULL) {
		return lista;
	}
	ListNode *iter = NULL, *temp = NULL;
	iter = lista->santinela->next;
	while (iter != NULL) {
		free(iter->elem);
		temp = iter;
		iter = iter->next;
		free(temp);
	}
	free(lista->santinela->elem);
	free(lista->santinela);
	free(lista);
	return NULL;
}
