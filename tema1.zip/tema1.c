/*OLTEANU Andreea-Denisa - 311 CD*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Operatii.h"

int main() {
	// Creez banda, stivele pentru undo si redo si coada pentru operatii
	List *banda = createBanda();
	Stack *stiva_undo = createStack(), *stiva_redo = createStack();
	Queue *operatii = createQueue();
	FILE *fisier_in, *fisier_out;
	int nr_op = 0;
	fisier_in = fopen("tema1.in", "r");
	fisier_out = fopen("tema1.out", "w");
	fscanf(fisier_in, "%d\n", &nr_op);
	// Citesc din fisier pana cand raman fara operatii
	while (nr_op > 0) {
		char *str = (char *)malloc(string_len*sizeof(char));
		fgets(str, string_len, fisier_in);
		// Verificam ce operatie trebuie facuta si o executam
		if (strstr(str, "EXECUTE")) {
			EXECUTE(banda, operatii, stiva_undo, stiva_redo, fisier_out);
		} else if (strstr(str, "SHOW_CURRENT")) {
				SHOW_CURRENT(banda, fisier_out);
		} else if (strstr(str, "SHOW")) {
				SHOW(banda, fisier_out);
		} else if (strstr(str, "UNDO")) {
				UNDO(banda, stiva_undo, stiva_redo);
		} else if (strstr(str, "REDO")) {
				REDO(banda, stiva_undo, stiva_redo);
		} else {
			enqueue(operatii, str);
	   }
		nr_op--;
		free(str);
    }
	// Coada cu operatii este goala la finalul programului
	free(operatii->front);
	free(operatii->rear);
	free(operatii);
	destroyList(banda);
	destroyStack(stiva_undo);
	destroyStack(stiva_redo);
	fclose(fisier_in);
	fclose(fisier_out);
}
